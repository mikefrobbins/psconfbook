function Test-Function {
    param (
        $FirstParameter
    )
    Write-Output $FirstParameter
}