$data = . $PSScriptRoot\data.ps1
$data | Export-Excel