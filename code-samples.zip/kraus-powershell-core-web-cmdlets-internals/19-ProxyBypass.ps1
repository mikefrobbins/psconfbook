$Uri = 'Https://httpbin.org/get'
Invoke-RestMethod -Uri $Uri -NoProxy