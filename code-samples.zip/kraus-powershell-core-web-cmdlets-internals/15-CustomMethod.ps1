$Uri = 'https://mockbin.com/request'
Invoke-RestMethod -CustomMethod 'SEARCH' -Uri $Uri